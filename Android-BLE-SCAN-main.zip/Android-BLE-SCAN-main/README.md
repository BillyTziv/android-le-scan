# Android-BLE-SCAN
1.Permissions
https://punchthrough.com/android-ble-guide/
https://developer.android.com/training/permissions/requesting
https://www.geeksforgeeks.org/android-how-to-request-permissions-in-android-application/
https://github.com/Jasonchenlijian/FastBle/blob/master/app/src/main/java/com/clj/blesample/MainActivity.java
